import Lesson20 from "./Lesson20";

export default Lesson20;