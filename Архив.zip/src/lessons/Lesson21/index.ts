import Lesson21 from "./Lesson21";

export default Lesson21;