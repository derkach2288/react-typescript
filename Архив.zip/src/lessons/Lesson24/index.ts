import Lesson24 from "./Lesson24";

export default Lesson24;