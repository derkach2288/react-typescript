import Lesson22 from "./Lesson22";

export default Lesson22;
