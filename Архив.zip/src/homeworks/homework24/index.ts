import Homework24 from "./Homework24";

export default Homework24;