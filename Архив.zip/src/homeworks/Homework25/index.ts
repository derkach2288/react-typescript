import Homework25 from "./Homework25";

export default Homework25;