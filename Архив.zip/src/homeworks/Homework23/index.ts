import Homework23 from "./Homework23";

export default Homework23;