import { Homework22Wrapper, LoginCard, LoginFormName } from "./styles";

function Homework22V2() {
  return (
    <Homework22Wrapper>
      <LoginCard>
        <LoginFormName>Login form</LoginFormName>
      </LoginCard>
    </Homework22Wrapper>
  );
}

export default Homework22V2;
