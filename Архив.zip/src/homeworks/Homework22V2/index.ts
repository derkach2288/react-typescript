import Homework22V2 from "./Homework22V2";

export default Homework22V2;
