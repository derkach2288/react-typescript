import Homework20 from "./Homework20";

export default Homework20;
