import "./App.css";
import Lesson20 from "./lessons/Lesson20";
import Homework20 from "./homeworks/Homework20";
import Lesson21 from "./lessons/Lesson21";
import Homework21 from "./homeworks/Homework21";

function App() {
  return (
    <div className="App">
      {/* <Lesson20 /> */}
      {/* <Homework20 /> */}
      {/* <Lesson21 /> */}
      <Homework21 />
    </div>
  );
}

export default App;
