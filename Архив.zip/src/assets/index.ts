export {default as LikeIcon} from "./like.png"
export {default as DisLikeIcon} from "./dislike.png"