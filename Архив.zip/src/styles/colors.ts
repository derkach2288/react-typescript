interface Colors {
  primary: string;
  button: string
}

export const colors: Colors = {
  primary: "rgb(26, 35, 53)",
  button: "#050599"
};